VRML97 Scenegraph modelling objects for Python 

This project provides a core semantic model for VRML97 objects which
is close to (but not identical to) that specified in the VRML97 spec.
It is primarily used for the OpenGLContext project's VRML97 rendering
engine, but can also be used for generating, parsing or processing VRML97 
scenegraphs.


