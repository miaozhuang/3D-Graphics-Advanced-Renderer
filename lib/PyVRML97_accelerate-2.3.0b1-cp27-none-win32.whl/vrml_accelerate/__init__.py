"""PyVRML97 Accelerator module"""
__version__ = "2.3.0b1"
